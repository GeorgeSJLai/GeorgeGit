#include <inttypes.h>

#include "ndslib.h"
#include "core_v5.h"
#include "interrupt.h"

void ecall_handler(SAVED_CONTEXT * context) {
	context->mepc = read_csr(NDS_MEPC) + 4;

	long micm_cfg	= read_csr(NDS_MICM_CFG);
	long ic_exist	= ((micm_cfg >> 6) & 0x7) != 0;
	long mdcm_cfg	= read_csr(NDS_MDCM_CFG);
	long dc_exist	= ((mdcm_cfg >> 6) & 0x7) != 0;
	     micm_cfg	= read_csr(NDS_MICM_CFG);
	long ilm_exist	= ((micm_cfg >> 15) & 0x1f) != 0;
	     micm_cfg	= read_csr(NDS_MICM_CFG);
	long xonly_support	= ((micm_cfg >> 23) & 0x1) != 0;

	// Ignore the testing in case of no Icache and Dcache
	if (ic_exist == 0 && dc_exist == 0) {
                skip();
	}

	if (ilm_exist == 1 && xonly_support == 1) {
		exit (0);
	}

	// Turn on Icache and Dcache
	if (ic_exist != 0) {
		set_csr(NDS_MCACHE_CTL,1);
	}
	if (dc_exist != 0) {
		set_csr(NDS_MCACHE_CTL,2);
	}

}

int main (int argc, char** argv) {

	// Set ECALL handler
	general_exc_handler_tab[TRAP_U_ECALL] = ecall_handler;
	general_exc_handler_tab[TRAP_S_ECALL] = ecall_handler;
	general_exc_handler_tab[TRAP_M_ECALL] = ecall_handler;

	asm volatile("ecall");

	long i, j;
	long offset;

	int data_pat    = 0xf1f11ff1;
	int data_1;
	int data_2;

	int ret_insn    = 0x00008067;// jr ra
	int abort_insn  = 0x00000000;// illegal instrution
	int *ptr;

	// Save RA
	volatile int save_ra;
	asm volatile("mv %0, ra" : "=r"(save_ra));

	// Test D-Cache
	offset	= (2048 - 4) / 4;
	// Store data
	asm volatile("la %0, test_data" : "=r"(ptr));
	for(i = 0;i < 15; i++) {
		data_1  = *ptr;
		data_1 += data_pat;
		ptr    += offset;
		*ptr    = data_1;
	}
	// Check data
	asm volatile("la %0, test_data" : "=r"(ptr));
	data_2  = *ptr;
	for(i = 0;i < 15; i++) {
		data_1  = *ptr;
		if((data_1 ^ data_2) != 0) {
			exit(1);
		}
		data_2 += data_pat;
		ptr    += offset;
	}

	// Test I-Cache
	offset	= 2048 / 4;
	// Store instruction
	asm volatile("la %0, test_jump" : "=r"(ptr));
	for(i = 0;i < 15; i++) {
		*ptr = ret_insn;
		for(j = 0;j < 8; j++) {
			ptr += 1;
			*ptr = abort_insn;
		}
		ptr = ptr - 8 + offset;
	}

	// Write-back all data in caches
	asm volatile ("fence.i");

	// Load instruction
	asm volatile ("la %0, test_jump" : "=r"(ptr));
	for(i = 0;i < 15; i++) {
		asm volatile ("jalr %0" :: "r"(ptr));
		ptr += offset;
	}
	// Load/Store space
	asm volatile("j test_jump_end");
	asm volatile(".align 2");
	asm volatile("test_data:");
	asm volatile("test_jump:");
	asm volatile(".fill 8192, 4, 0x00000000");
	asm volatile("test_jump_end:");

	// Restore RA
	asm volatile("mv ra, %0" : "=r"(save_ra));
}


