#include "ace_user.h"
#include "stdlib.h"


int main() {
	// check if ACE support or not
	check_ace_support();

	// Setup system register to enable ACE
	enable_ace();

	// Test reverse_acr
	rvs_acr_t acr_data;
	unsigned long long acr_expected_data;
	acr_data = 0x12345678aabbccdd;
	acr_expected_data = 0xddccbbaa78563412;

	acr_data = ace_reverse_acr(acr_data);
	if (acr_expected_data != acr_data) {
		return(1);
	}

	// Test reverse_mem
	unsigned long long *mem_addr, mem_data, mem_expected_data;
	mem_addr = (unsigned long long*)malloc(sizeof(unsigned long long));
	*mem_addr = 0x12345678aabbccdd;
	mem_expected_data = 0xddccbbaa78563412;

	ace_reverse_mem((uintptr_t)mem_addr);
	mem_data =  *mem_addr;
	if (mem_expected_data != mem_data) {
		return(1);
	}
	free(mem_addr);

	// Test reverse_gpr
	unsigned long long gpr_data, gpr_expected_data;
	gpr_data = 0x12345678aabbccdd;
	gpr_expected_data = 0xddccbbaa78563412;

	gpr_data = ace_reverse_gpr(gpr_data);
	if (gpr_expected_data != gpr_data) {
		return(1);
	}

	// Test add_200
	acrw200_t add_data, add_expected_data;
	add_data.dword0 = 0x0;
	add_data.dword1 = 0x0;
	add_data.dword2 = 0x0;
	add_data.msb_8 = 0x80;
	add_expected_data.dword0 = 0xddccbbaa78563412;
	add_expected_data.dword1 = 0x0;
	add_expected_data.dword2 = 0x0;
	add_expected_data.msb_8 = 0x80;

	ace_add_200(add_data, gpr_data);
	add_data = ace_rd_acrw200(acrw200_0);
	if (add_expected_data.dword0 != add_data.dword0) {
		return(1);
	}
	if (add_expected_data.dword1 != add_data.dword1) {
		return(1);
	}
	if (add_expected_data.dword2 != add_data.dword2) {
		return(1);
	}
	if (add_expected_data.msb_8 != add_data.msb_8) {
		return(1);
	}

	// Test multiply_accumulate_vec
	unsigned long long ret, expected_ret;
	acrw8_t	cnt;
	unsigned int i;
	unsigned long long a = 0x8323928;
	unsigned long long b = 0x1a2b3c4;
	cnt = 0xf5;

	ret = ace_gpr_accumulate_vec(a, b, cnt);
	expected_ret = 0;
	for (i = 0; i < 5; i++) {
		expected_ret += a + b;
	}
	if (expected_ret != ret) {
		return(1);
	}
	
	return(0);
}
