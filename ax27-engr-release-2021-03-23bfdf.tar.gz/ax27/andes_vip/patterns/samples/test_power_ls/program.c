
#include "ndslib.h"

#define OUT_LOOP_NUM        30
#define INNER_LOOP_NUM      30

int main (int argc, char** argv) {
	long volatile *mem = malloc(0x20 * sizeof(long));
	long i;
	long j;
	long data1 = 67629137;
	long data2 = 73939133;

	*(mem + 0x00)  = data1;
	*(mem + 0x04)  = data2;
	*(mem + 0x08)  = data1;
	*(mem + 0x0c)  = data2;
	*(mem + 0x10)  = data1;
	*(mem + 0x14)  = data2;
	*(mem + 0x18)  = data1;
	*(mem + 0x1c)  = data2;

	for (i = 0; i < OUT_LOOP_NUM; i = i + 1) {
		data2 = *(mem + 0x00);
		data1 = *(mem + 0x04);
		data2 = *(mem + 0x08);
		data1 = *(mem + 0x0c);
		data2 = *(mem + 0x10);
		data1 = *(mem + 0x14);
		data2 = *(mem + 0x18);
		data1 = *(mem + 0x1c);
		for (j = 0; j < INNER_LOOP_NUM; j = j + 1) {
			*(mem + 0x00)  = data2;
			*(mem + 0x04)  = data1;
			*(mem + 0x08)  = data2;
			*(mem + 0x0c)  = data1;
			*(mem + 0x10)  = data2;
			*(mem + 0x14)  = data1;
			*(mem + 0x18)  = data2;
			*(mem + 0x1c)  = data1;

			data2 = *(mem + 0x00);
			data1 = *(mem + 0x04);
			data2 = *(mem + 0x08);
			data1 = *(mem + 0x0c);
			data2 = *(mem + 0x10);
			data1 = *(mem + 0x14);
		}
		data2 = *(mem + 0x18);
		data1 = *(mem + 0x1c);
		data2 = *(mem + 0x08);
		data1 = *(mem + 0x0c);
		data2 = *(mem + 0x10);
		data1 = *(mem + 0x14);
	}
}
