// Copyright (C) 2021, Andes Technology Corp. Confidential Proprietary

#include <inttypes.h>

#include "platform.h"
#include "ndslib.h"
#include "core_v5.h"
#include "interrupt.h"

#ifndef NDS_TIMEOUT_COUNT
#define NDS_TIMEOUT_COUNT 100000
#endif

#ifndef NDS_RESUME_MIN
#define NDS_RESUME_MIN 1000
#endif

volatile static uint32_t pit_isr_flag = 0;
volatile static uint32_t isr_sync = 0;

void enable_interrupt(uint32_t intr_no) {
#ifdef NDS_AE350_MULTI_HART
	__nds__plic_set_priority(intr_no, 1);
	DEV_PLIC->TARGET_EN[NDS_AE350_PLIC_MTGT].INT_EN[0] |= (1 << (intr_no & 0x1F));
	DEV_PLIC->TARGET_EN[NDS_AE350_PLIC_STGT].INT_EN[0] &= 0x0;
#else
	__nds__plic_set_priority(intr_no, 1);
	__nds__plic_enable_interrupt(intr_no);
#endif
}

void disable_interrupt(uint32_t intr_no) {
	__nds__plic_set_priority(intr_no, 0);
}

void ecall_handler(SAVED_CONTEXT * context) {
        context->mepc += 4;
        context->mstatus |= MSTATUS_MPP; 
}

static void pit_isr(uint32_t int_no)
{
	(*intr_disable_ptr)(int_no);
	DEV_PIT->INTEN = 0x0;

	(*intr_clear_ptr)(int_no);

	pit_isr_flag = DEV_PIT->INTST;
	DEV_PIT->INTST = pit_isr_flag;

	(*intr_enable_ptr)(int_no);
}

void mswi_handler(void)
{
	__nds__plic_sw_claim_interrupt();

	__nds__plic_sw_complete_interrupt(1);

	isr_sync = 1;
}

void enable_dcache () {
	long mdcm_cfg = 0;
        long mcache_ctl = 0;

        mdcm_cfg = read_csr(NDS_MDCM_CFG);

	if (((mdcm_cfg >> 6) & 0x7) > 0) {
		mcache_ctl = read_csr(NDS_MCACHE_CTL);
		if (((mcache_ctl >> 1) & 0x1) == 0) {  
			mcache_ctl |= 0x2;
			write_csr(NDS_MCACHE_CTL, mcache_ctl);
		}
	}

	return 0;
}

void disable_dcache () {
	long mdcm_cfg = 0;
        long mcache_ctl = 0;

        mdcm_cfg = read_csr(NDS_MDCM_CFG);

	if (((mdcm_cfg >> 6) & 0x7) > 0) {
		mcache_ctl = read_csr(NDS_MCACHE_CTL);
		if (((mcache_ctl >> 1) & 0x1) == 1) {  
			mcache_ctl &= 0xfffffffd;
			write_csr(NDS_MCACHE_CTL, mcache_ctl);
		}
	}

	return 0;
}

void flush_cctl () {
	uint32_t l2c_exist = (DEV_SMU->SYSTEMCFG >> 8) & 0x1;

	if (l2c_exist) {
		uint32_t l2c_cache_size = (DEV_L2C->CONFIG >> 7) & 0x1f;
		if (l2c_cache_size != 0) {
			DEV_L2C->M0_CCTL_CMD = 0b10010 ; 
			do {

			} while(DEV_L2C->CCTL_ST != 0x0);
		}
	}

	__asm__ __volatile__ ("fence.i");
}

void main_core () {
	int hart_num;
	uint32_t tmp32;

	hart_num  = DEV_SMU->SYSTEMCFG & 0xff;
	if (hart_num > 1) {
		DEV_PLIC_SW->TARGET_EN[1].INT_EN[0] |= 0x200;
		DEV_PLIC_SW->TARGET_EN[2].INT_EN[0] |= 0x400;
		DEV_PLIC_SW->TARGET_EN[3].INT_EN[0] |= 0x800;
		DEV_PLIC_SW->INT_PEND[0] = 0xe00;
	}

	clear_csr(NDS_MIE, MIP_MSIP);
	clear_csr(NDS_MIE, MIP_MTIP);

	clear_csr(NDS_MSTATUS, MSTATUS_MIE);

	if (hart_num > 1) {
		int i;
		for (i = 1; i < hart_num; i++) {
			do {
				tmp32 = DEV_SMU->PCS[3 + i].PCS_STATUS;
			} while (tmp32 & ATCSMU100_PCS_STATUS_PD_TYPE != ATCSMU100_PCS_STATUS_SLEEP);
		}
	}

	DEV_SMU->PCS[3].PCS_WE = 0xffffffff;

	DEV_SMU->PCS[3].PCS_CTL = 0x3;

	flush_cctl();
	disable_dcache();

	intr_enable_ptr = enable_interrupt;
	intr_disable_ptr = disable_interrupt;
	(*intr_setup_ptr)(INT_NO_PIT, pit_isr);
	(*intr_enable_ptr)(INT_NO_PIT);
	DEV_PIT->CHANNEL[0].CTRL = ATCPIT100_MODE_TMR16 | ATCPIT100_CLK_PCLK;
        tmp32 = rand();
        DEV_PIT->CHANNEL[0].RELOAD = NDS_RESUME_MIN + (tmp32 & 0xff);
        DEV_PIT->INTEN = 0x1;
        DEV_PIT->CHNEN = 0x1;
	DEV_PLIC->TARGET_EN[0].INT_EN[3] |= 0x8;

	__asm__ __volatile__ ("wfi");

	enable_dcache();

	if (hart_num > 1) {
		DEV_PLIC_SW->TARGET_EN[1].INT_EN[0] |= 0x200;
		DEV_PLIC_SW->TARGET_EN[2].INT_EN[0] |= 0x400;
		DEV_PLIC_SW->TARGET_EN[3].INT_EN[0] |= 0x800;
		DEV_PLIC_SW->INT_PEND[0] = 0xe00;
	}

	if (hart_num > 1) {
		int i;
		for (i = 1; i < hart_num; i++) {
			do {
				tmp32 = DEV_SMU->PCS[3 + i].PCS_STATUS;
			} while (tmp32 & ATCSMU100_PCS_STATUS_PD_TYPE != ATCSMU100_PCS_STATUS_ACTIVE);
		}
	}



	if (hart_num > 1) {
		int i;
		for (i = 1; i < hart_num; i++) {
			do {
				tmp32 = DEV_SMU->PCS[3 + i].PCS_SCRATCH;
			} while (tmp32 != 0x12345678);
		}
	}
}

void other_cores (uint32_t run_id) {
        int i;

	set_csr(NDS_MIE, MIP_MSIP);
	for (i = 0; i < NDS_TIMEOUT_COUNT; i++) {
                if (isr_sync) {
			break;
		}
        }
	if (i == NDS_TIMEOUT_COUNT) {
		exit(2);
	}

	clear_csr(NDS_MIE, MIP_MSIP);
	clear_csr(NDS_MIE, MIP_MTIP);

	clear_csr(NDS_MSTATUS, MSTATUS_MIE);

	DEV_SMU->PCS[3 + run_id].PCS_WE = 0xffffffff;

	DEV_SMU->PCS[3 + run_id].PCS_CTL = 0x3;

	flush_cctl();
	disable_dcache();

	set_csr(NDS_MIE, MIP_MSIP);
	__asm__ __volatile__ ("wfi");


	enable_dcache();


	DEV_SMU->PCS[3 + run_id].PCS_SCRATCH = 0x12345678;
}

int main (int argc, char** argv) {
	uint32_t run_id = 0;

        general_exc_handler_tab[TRAP_U_ECALL] = ecall_handler;
        general_exc_handler_tab[TRAP_S_ECALL] = ecall_handler;
        general_exc_handler_tab[TRAP_M_ECALL] = ecall_handler;

        asm volatile("ecall");

	run_id = read_csr(NDS_MHARTID);

	if (run_id == 0) {
		main_core();
	}
	else {
		other_cores(run_id);
	}

	exit(0);
}
