/* redefine printf to nop */

#ifndef dummy_printf
#define dummy_printf(fmt, ...)
#endif

#define printf dummy_printf

