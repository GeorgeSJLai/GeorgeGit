
#ifndef __RAND_H__
#define __RAND_H__

#ifndef SEED
#define SEED	0x87654321
#endif

extern unsigned int nds_lfsr_seed;

#endif // __RAND_H__
