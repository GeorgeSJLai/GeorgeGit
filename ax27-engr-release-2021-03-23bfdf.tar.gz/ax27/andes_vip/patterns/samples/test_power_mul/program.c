
#include "ndslib.h"

#define OUT_LOOP_NUM        30
#define INNER_LOOP_NUM      30

#if __riscv_xlen == 64
	#define EXPECTED_VALUE1     0x00000083566dedc3ul
	#define EXPECTED_VALUE2     0x00000004449f6061ul
	#define EXPECTED_VALUE3     0xc53bfd7f9a64ece3ul
	#define EXPECTED_VALUE4     0x3e3bc4087b4193b9ul
#else
	#define EXPECTED_VALUE1     0x566dedc3
	#define EXPECTED_VALUE2     0x449f6061
	#define EXPECTED_VALUE3     0x9a64ece3
	#define EXPECTED_VALUE4     0x7b4193b9
#endif

int main (int argc, char** argv) {
	long i;
	long j;
	long reg2 = 67629137;
	long reg3 = 73939133;
	long reg4 = 7393913;
	long reg5 = 7629137;
	long reg6 = 629137;
	long reg7 = 73939;
	long reg8 = 29137;

	asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg5));
	asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg6));

	if (reg7 != EXPECTED_VALUE1) exit(1);
	if (reg8 != EXPECTED_VALUE2) exit(2);

	for (i = 0; i < OUT_LOOP_NUM; i = i + 1) {
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg2));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg3));
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg4));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg5));
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg6));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg2));
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg3));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg4));

		for (j = 0; j < INNER_LOOP_NUM; j = j + 1) {
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg5));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg6));
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg2));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg3));
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg4));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg5));
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg6));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg2));

			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg3));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg4));
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg5));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg6));
			asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg2));
			asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg3));
		}
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg4));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg5));
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg6));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg2));
		asm volatile ("mul %0, %1, %2" : "=r"(reg7) : "r"(reg7), "r"(reg3));
		asm volatile ("mul %0, %1, %2" : "=r"(reg8) : "r"(reg8), "r"(reg4));
	}

	if (reg7 != EXPECTED_VALUE3) exit(3);
	if (reg8 != EXPECTED_VALUE4) exit(4);

}
