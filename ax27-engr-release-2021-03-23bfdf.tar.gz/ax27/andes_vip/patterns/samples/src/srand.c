// Copyright (C) 2021, Andes Technology Corp. Confidential Proprietary


#include "rand.h"

void srand(unsigned int seed) {
	nds_lfsr_seed = seed;
}


