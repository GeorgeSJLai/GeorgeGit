// Copyright (C) 2021, Andes Technology Corp. Confidential Proprietary

#include <inttypes.h>
#include "rand.h"


unsigned int nds_lfsr_seed = SEED;


int rand(void) {
	nds_lfsr_seed = (nds_lfsr_seed >> 1) ^ (-(nds_lfsr_seed & 1u) & 0xd0000001u);

	return ((int)nds_lfsr_seed);
}

long int lrand(void) {
	return ((((long int)rand()) << 32) | ((long int)rand()));
}
