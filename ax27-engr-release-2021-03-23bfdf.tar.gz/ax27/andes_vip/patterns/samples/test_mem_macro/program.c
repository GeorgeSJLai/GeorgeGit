int main() {
        asm("wfi");
}
