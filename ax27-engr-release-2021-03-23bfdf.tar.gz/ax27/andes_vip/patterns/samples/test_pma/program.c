/*
 * Copyright (c) 2012-2019 Andes Technology Corporation
 * All rights reserved.
 *
 */
/*
 * This demo program shows how to configure memory attribute by PMA.
 *
 * Scenario:
 *
 * The demo first checks whether the PMA feature is supported or not. Then, initializes pma configuration of
 * three regions with "A" & "B" non-cacheable and "C" cacheable attribute to overwrite the background cacheable
 * attribute and turns on the cache. Next, it reads a single region with different cache attributes and compares
 * the number of dcache accesses. Similarly, it also reads two different cache attribute regions and compares the
 * number of dcache accesses.
 * Finally, it modifies a single cacheable region and does flush cache before changing cache attribute.
 * It also reads a single region with different cache attributes to compare the number of dcache accesses.
 */

/* Feature requirement
 * PMA support (entry >= 3)
 * PFM support
 * CCTL(CACHE) support
 * Limited DLM size*
 */

#include <stdio.h>
#include <inttypes.h>
#include "platform.h"

#include "ndslib.h"
#include "core_v5.h"
#include "interrupt.h"

/* SMU.SYSTEMCFG Configuration Register */
#define L2C_CTL_OFF                             8
#define L2C_CTL_MSK                             (0x1 << L2C_CTL_OFF)
#define L2C_LINE_SIZE                           32

/* Control Register */
#define L2C_ENABLE                              0x1

/* CSR NDS_MMSC_CFG */
#define CCTLCSR_MSK                             (1ULL << (16))
#define VCCTL_MSK                               ((1ULL << (18)) | (1ULL << (19)))
#define DPMA_MSK                                (1ULL << (30))
#define NOPMC_MSK                               (1ULL << (22))

/* CSR NDS_MDCM_CFG */
#define DLMSZ_MSK                               (0x1fULL << (15))
#define DLMSZ_LSB                               15

/* L1C CCTL Command Index */
#define CCTL_L1D_VA_INVAL                       0
#define CCTL_L1D_VA_WB                          1
#define CCTL_L1D_VA_WBINVAL                     2
#define CCTL_L1D_VA_LOCK                        3
#define CCTL_L1D_VA_UNLOCK                      4
#define CCTL_L1D_WBINVAL_ALL                    6
#define CCTL_L1D_WB_ALL                         7
#define CCTL_L1I_VA_INVAL                       8
#define CCTL_L1I_VA_LOCK                        11
#define CCTL_L1I_VA_UNLOCK                      12
#define CCTL_L1D_IX_INVAL                       16
#define CCTL_L1D_IX_WB                          17
#define CCTL_L1D_IX_WBINVAL                     18
#define CCTL_L1D_IX_RTAG                        19
#define CCTL_L1D_IX_RDATA                       20
#define CCTL_L1D_IX_WTAG                        21
#define CCTL_L1D_IX_WDATA                       22
#define CCTL_L1D_INVAL_ALL                      23
#define CCTL_L1I_IX_INVAL                       24
#define CCTL_L1I_IX_RTAG                        27
#define CCTL_L1I_IX_RDATA                       28
#define CCTL_L1I_IX_WTAG                        29
#define CCTL_L1I_IX_WDATA                       30

/* L1C CCTL Command Index */
#define CCTL_L2_IX_INVAL                        0x0
#define CCTL_L2_IX_WB                           0x1
#define CCTL_L2_IX_WBINVAL                      0x2
#define CCTL_L2_PA_INVAL                        0x8
#define CCTL_L2_PA_WB                           0x9
#define CCTL_L2_PA_WBINVAL                      0xA
#define CCTL_L2_TGT_WRITE                       0x10
#define CCTL_L2_TGT_READ                        0x11
#define CCTL_L2_WBINVAL_ALL                     0x12

#define ISIZE_MSK                               0x1C0
#define DSIZE_MSK                               0x1C0

/* Text regions */
#define TEXT_REGION_BASE_PA                     __executable_start
#define TEXT_REGION_SIZE                        0x8000

/* Test regions */
//#define TEST_ARRAY_SIZE                       16*(0x1<<10)
#define TEST_ARRAY_SIZE                         0x1 << 10
#define ALIGN_SIZE                              (32*(0x1<<10))
#define TEST_REGION_A
#define TEST_REGION_B
#define TEST_REGION_C
#define TEST_REGION_SIZE                        TEST_ARRAY_SIZE * 3

/* MSTATUS related macros */
#define PRIV_M          3
#define PRIV_S          1
#define PRIV_U          0

/* HPMEVENT macros */
#define EVENT_DCACHE_ACCESS  ((0x6 << 4) | 0x1)

#define DBG_PRINT(fmt, args...)
#define P2ALIGN(x, n)        (((x) + n - 1) & ~(n - 1))
#define CHECK_CACHE_ACCESS_COUNT(acc_cache, acc_uncache, load_count) ((acc_cache - acc_uncache) >= load_count)

/* secondary region settings */
// When default test region are not in memory, pattern will try to use secondary region
// If secondary region is also mapped to local memory, pattern will be skipped
#define SECONDARY_REGION_BASE   DDR3_MEM_BASE

extern unsigned char __executable_start[];      // Map to __TEXT_BASE in ld script
extern unsigned char _stack[];
unsigned char *A_Array;
unsigned char *B_Array;
unsigned char *C_Array;

__attribute__((always_inline))
static inline unsigned long long rd_cache_load_miss_count(void)
{
#if __riscv_xlen == 32
	do {
		unsigned long hi = read_csr(NDS_MHPMCOUNTER3H);
		unsigned long lo = read_csr(NDS_MHPMCOUNTER3);

		if (hi == read_csr(NDS_MHPMCOUNTER3H))
			return ((unsigned long long)hi << 32) | lo;
	} while(1);
#else
	return read_csr(NDS_MHPMCOUNTER3);
#endif
}

__attribute__((always_inline))
static inline void init_cache_load_miss_count(void)
{
        unsigned long event = EVENT_DCACHE_ACCESS;
        unsigned long init_cnt = 0;
        write_csr(NDS_MHPMEVENT3, event);

        write_csr(NDS_MHPMCOUNTER3,  init_cnt);
#if __riscv_xlen == 32
        write_csr(NDS_MHPMCOUNTER3H, init_cnt);
#endif
}

unsigned long long read_region(unsigned char* va, unsigned int size)
{
	unsigned int i;
	unsigned char dummy = 0;
	volatile unsigned char vdummy = 0;

	/* Try to 1st read region from DDR to cache if cacheable memory */
	for(i = 0; i < size; i++) {
		dummy += va[i];
	}
	vdummy += dummy;

        /* cache miss counts start */
        init_cache_load_miss_count();

	/* Try to 2nd read region from cache if cacheable memory */
	for(i = 0; i < size; i++) {
		dummy += va[i];
	}
	vdummy += dummy;

	/* get cache load miss count */
        return rd_cache_load_miss_count();
}

void write_region(unsigned char* va, unsigned int size, char c)
{
	unsigned int i;

	for(i = 0; i < size; i++) {
		va[i] = c;
	}
}

int check_region(unsigned char* va, unsigned int size, char c)
{
	unsigned int i;

	for(i = 0; i < size; i++) {
		if (!(c == va[i])) {
			return 0;
		}
	}

	return 1;
}

void region_pma_config(void* va, unsigned int size, char entry, char pmacfg)
{
	switch (entry) {
	case 0:
		write_csr(NDS_PMAADDR0_, NAPOT(va, size));
		break;
	case 1:
		write_csr(NDS_PMAADDR1_, NAPOT(va, size));
		break;
	case 2:
		write_csr(NDS_PMAADDR2_, NAPOT(va, size));
		break;
	case 3:
		write_csr(NDS_PMAADDR3_, NAPOT(va, size));
		break;
	case 4:
		write_csr(NDS_PMAADDR4_, NAPOT(va, size));
		break;
	case 5:
		write_csr(NDS_PMAADDR5_, NAPOT(va, size));
		break;
	case 6:
		write_csr(NDS_PMAADDR6_, NAPOT(va, size));
		break;
	case 7:
		write_csr(NDS_PMAADDR7_, NAPOT(va, size));
		break;
	case 8:
		write_csr(NDS_PMAADDR8_, NAPOT(va, size));
		break;
	case 9:
		write_csr(NDS_PMAADDR9_, NAPOT(va, size));
		break;
	case 10:
		write_csr(NDS_PMAADDR10_, NAPOT(va, size));
		break;
	case 11:
		write_csr(NDS_PMAADDR11_, NAPOT(va, size));
		break;
	case 12:
		write_csr(NDS_PMAADDR12_, NAPOT(va, size));
		break;
	case 13:
		write_csr(NDS_PMAADDR13_, NAPOT(va, size));
		break;
	case 14:
		write_csr(NDS_PMAADDR14_, NAPOT(va, size));
		break;
	case 15:
		write_csr(NDS_PMAADDR15_, NAPOT(va, size));
		break;
	}

#if __riscv_xlen == 64
	switch (entry >> 3){
	case 0:
		write_csr(NDS_PMACFG0_, ((read_csr(NDS_PMACFG0_) & (~((0xFFULL) << ((entry%8) << 3)))) | (((long)pmacfg) << ((entry%8) << 3))));
		break;
	case 1:
		write_csr(NDS_PMACFG2_, ((read_csr(NDS_PMACFG2_) & (~((0xFFULL) << ((entry%8) << 3)))) | (((long)pmacfg) << ((entry%8) << 3))));
		break;
	}
#else
	switch (entry >> 2) {
	case 0:
		write_csr(NDS_PMACFG0_, ((read_csr(NDS_PMACFG0_) & (~((0xFF) << ((entry%4) << 3)))) | (((long)pmacfg) << ((entry%4) << 3))));
		break;
	case 1:
		write_csr(NDS_PMACFG1_, ((read_csr(NDS_PMACFG1_) & (~((0xFF) << ((entry%4) << 3)))) | (((long)pmacfg) << ((entry%4) << 3))));
		break;
	case 2:
		write_csr(NDS_PMACFG2_, ((read_csr(NDS_PMACFG2_) & (~((0xFF) << ((entry%4) << 3)))) | (((long)pmacfg) << ((entry%4) << 3))));
		break;
	case 3:
		write_csr(NDS_PMACFG3_, ((read_csr(NDS_PMACFG3_) & (~((0xFF) << ((entry%4) << 3)))) | (((long)pmacfg) << ((entry%4) << 3))));
		break;
	}
#endif
}

void init_test_array(const uintptr_t ptr_test_base)
{
        A_Array = (unsigned char *)P2ALIGN(ptr_test_base + ALIGN_SIZE*0, ALIGN_SIZE);
        B_Array = (unsigned char *)P2ALIGN(ptr_test_base + ALIGN_SIZE*1, ALIGN_SIZE);
        C_Array = (unsigned char *)P2ALIGN(ptr_test_base + ALIGN_SIZE*2, ALIGN_SIZE);
}

int lm_overlap_check(const uintptr_t ptr_begin, const uintptr_t ptr_end)
{
	uintptr_t ilm_size_code = ((read_csr(NDS_MICM_CFG) >> 15) & 0x1FUL);
	uintptr_t ilm_size_kb = (ilm_size_code > 0)? (1UL << (ilm_size_code - 1)) : 0;
	uintptr_t ilm_size = ilm_size_kb << 10;
        /* Check whether ILM is supported */
        if (ilm_size > 0) {
                uintptr_t ilm_base = read_csr(NDS_MILMB);
                ilm_base = (ilm_base >> 10) << 10;

                if (!(ptr_end <= ilm_base || ptr_begin >= (ilm_base+ilm_size))) {
                        DBG_PRINT("Test region might overlap with ILM.\n");
                        return 1;
                }
        }

	uintptr_t dlm_size_code = ((read_csr(NDS_MDCM_CFG) >> 15) & 0x1FUL);
	uintptr_t dlm_size_kb = (dlm_size_code > 0)? (1UL << (dlm_size_code - 1)) : 0;
	uintptr_t dlm_size = dlm_size_kb << 10;
        /* Check whether DLM is supported */
        if (dlm_size > 0) {
                uintptr_t dlm_base = read_csr(NDS_MDLMB);
                dlm_base = (dlm_base >> 10) << 10;

                /* Check whether the test region is located in DLM. */
                if (!(ptr_end <= dlm_base || ptr_begin >= (dlm_base+dlm_size))) {
                        DBG_PRINT("Test region might overlap with DLM.\n");
                        return 1;
                }
        }
        return 0;
}

void init_pma_config(void)
{
	/* PMA entry 0 : A_Array (non-cacheable attribute) */
	region_pma_config((void*)A_Array, TEST_ARRAY_SIZE, 0, PMACFG_NME(PMA_NAMO_OFF, PMA_MTYP_NONCACHEABLE, PMA_ETYP_NAPOT));

	/* PMA entry 1 : B_Array (non-cacheable attribute) */
	region_pma_config((void*)B_Array, TEST_ARRAY_SIZE, 1, PMACFG_NME(PMA_NAMO_OFF, PMA_MTYP_NONCACHEABLE, PMA_ETYP_NAPOT));

	/* PMA entry 2 : C_Array (cacheable attribute) */
	region_pma_config((void*)C_Array, TEST_ARRAY_SIZE, 2, PMACFG_NME(PMA_NAMO_OFF, PMA_MTYP_CACHEABLE, PMA_ETYP_NAPOT));
}

void flush_cache(void* va, unsigned int size)
{
	unsigned int i;
	unsigned int tmp = 0;

	/* Check whether the CPU configured with CCTL auto-incremented feature. */
	if ((read_csr(NDS_MMSC_CFG) & VCCTL_MSK)) {
		unsigned long final_va = (unsigned long)(va + size);
		unsigned long next_va = (unsigned long)va;

		/* Write only once at the beginning, it will be updated by CCTL command CSR write operation */
		write_csr(NDS_MCCTLBEGINADDR, (unsigned long)va);

		/* L1C DCache write back and invalidate */
		while (next_va < final_va) {
			/* Write back and invalid one cache line each time */
			write_csr(NDS_MCCTLCOMMAND, CCTL_L1D_VA_WBINVAL);

			/* Read back from BEGINADDR csr for next va */
			next_va = read_csr(NDS_MCCTLBEGINADDR);
		}
	} else {
		unsigned int dsize = (unsigned int)(1 << (((read_csr(NDS_MDCM_CFG) & DSIZE_MSK) >> 6) + 2));

		/* L1C DCache write back and invalidate */
		for (i = 0; tmp < size; i++) {
			/* Write back and invalid one cache line each time */
			write_csr(NDS_MCCTLBEGINADDR, (unsigned long)(va + (i * dsize)));
			tmp += dsize;
			write_csr(NDS_MCCTLCOMMAND, CCTL_L1D_VA_WBINVAL);
		}
	}

	if (DEV_SMU->SYSTEMCFG & L2C_CTL_MSK) {
		/* L2C Cache write back and invalidate all */
		for (i = 0, tmp = 0; tmp < size; i++) {
			/* Write back and invalid one cache line each time */
			DEV_L2C->M0_CCTL_ACC = (unsigned long)(va + (i * L2C_LINE_SIZE));
			tmp += L2C_LINE_SIZE;
			DEV_L2C->M0_CCTL_CMD = CCTL_L2_PA_WBINVAL;
		}
	}
}

int enable_cache(void)
{
	/* Check whether the CPU configured with L1C cache. */
	if (!((read_csr(NDS_MDCM_CFG) & DSIZE_MSK) >> 6)) {
		return 0;
	}

	/* Enable L1C cache */
	write_csr(NDS_MCACHE_CTL, (read_csr(NDS_MCACHE_CTL) | 0x3));

	/* Check whether the CPU configured with L2C cache. */
	if (DEV_SMU->SYSTEMCFG & L2C_CTL_MSK) {
		/* Enable L2C cache */
		DEV_L2C->CTRL |= L2C_ENABLE;
	}

	return 1;
}

void ecall_handler(SAVED_CONTEXT * context) {
        context->mstatus = (context->mstatus & ~MSTATUS_MPP) | (PRIV_M  << 11);
        context->mepc += 4;

        return;
}

int main(void)
{
        unsigned int       run_test_A   = 0;
        unsigned int       run_test_B   = 0;
        unsigned int       run_test_C   = 0;
	unsigned long long dcache_access_count_cacheable_a;
	unsigned long long dcache_access_count_noncacheable_a;
	unsigned long long dcache_access_count_noncacheable_b;
	unsigned long long dcache_access_count_cacheable_c;
	unsigned long long dcache_access_count_noncacheable_c;

	DBG_PRINT("Andes V5 demo-pma program.\n");

        /* Pre configuration, Switch to M-mode */
        general_exc_handler_tab[TRAP_U_ECALL] = ecall_handler;
        general_exc_handler_tab[TRAP_S_ECALL] = ecall_handler;
        general_exc_handler_tab[TRAP_M_ECALL] = ecall_handler;
        asm volatile ("ecall");

	/* Check whether the CPU configured with PMA feature. */
	if (!(read_csr(NDS_MMSC_CFG) & DPMA_MSK)) {
		DBG_PRINT("This test pattern requires the PMA feature.\n");
		skip();
	} else {
                write_csr(NDS_PMAADDR0_, 0xffffffff);
                write_csr(NDS_PMAADDR1_, 0xffffffff);
                write_csr(NDS_PMAADDR2_, 0xffffffff);
                run_test_A = (read_csr(NDS_PMAADDR0_) != 0); // region A uses PMA0
                run_test_B = (read_csr(NDS_PMAADDR1_) != 0); // region B uses PMA1
                run_test_C = (read_csr(NDS_PMAADDR2_) != 0); // region C uses PMA2
        }

	/* Check whether the CPU configured with CCTL feature. */
	if (!(read_csr(NDS_MMSC_CFG) & CCTLCSR_MSK)) {
		DBG_PRINT("This test pattern requires CCTL (cache maintenance) operations.\n");
		skip();
	}

	/* Check whether the CPU configured with PFM feature. */
	if (read_csr(NDS_MMSC_CFG) & NOPMC_MSK) {
		DBG_PRINT("This test pattern requires performance monitors.\n");
		skip();
	}

        /* Init test array */
        init_test_array(&_stack);

        /* Check whether test array is on memory */
        if (lm_overlap_check((uintptr_t)A_Array, ((uintptr_t)C_Array) + ALIGN_SIZE)) {
                /* test array is on local memory, try to set it to secondary region */
                init_test_array((uintptr_t)SECONDARY_REGION_BASE);
                if (lm_overlap_check((uintptr_t)A_Array, ((uintptr_t)C_Array) + ALIGN_SIZE)) {
                        /* test array still on local memory, skip this pattern */
                        skip();
                }
        }

        /* Check whether test array overlaps text region */
        if (A_Array < TEXT_REGION_BASE_PA + TEXT_REGION_SIZE && C_Array + ALIGN_SIZE > TEXT_REGION_BASE_PA) {
                skip();
        }

	/* Init pma configuration of three regions with "A" & "B" non-cacheable and "C" cacheable attribute to overwrite background cacheable attribute. */
	init_pma_config();

	/* Enable cache */
	if (!enable_cache()) {
		DBG_PRINT("This test pattern requires caches.\n");
		skip();
	}

#ifdef TEST_REGION_A
        if (run_test_A) {
                /* Access non-cacheable attribute region "A" */
                DBG_PRINT("[Reconfigurable PMA]:Try to read A region from non-cacheable memory.\n");
                dcache_access_count_noncacheable_a = read_region(A_Array, TEST_ARRAY_SIZE);
                DBG_PRINT("dcache access count: %u.\n", (unsigned int)dcache_access_count_noncacheable_a);

                /* Disable pma configuration of the region "A" to recovery background attribute. */
		region_pma_config((void*)A_Array, TEST_ARRAY_SIZE, 0, PMACFG_NME(PMA_NAMO_OFF, PMA_MTYP_NONCACHEABLE, PMA_ETYP_PMA_OFF));

                /* Access cacheable attribute region "A" */
                DBG_PRINT("[Background PMA]:Try to read A region from cacheable memory.\n");
                dcache_access_count_cacheable_a = read_region(A_Array, TEST_ARRAY_SIZE);
                DBG_PRINT("dcache access count: %u.\n", (unsigned int)dcache_access_count_cacheable_a);

                /* Compare the number of dcache accesses of the same region "A" with cacheable and non-cacheable attribute */
                if (CHECK_CACHE_ACCESS_COUNT(dcache_access_count_cacheable_a, dcache_access_count_noncacheable_a, TEST_ARRAY_SIZE)) {
                        DBG_PRINT("PMA-Pass of the same region A with cacheable and non-cacheable attribute! \n");
                } else {
                        DBG_PRINT("PMA-Fail of the same region A with cacheable and non-cacheable attribute! \n");
                        exit(FAIL);
                }
        }
#endif // TEST_REGION_A
#ifdef TEST_REGION_B
        if (run_test_B) {
                /* Access non-cacheable attribute region "B" */
                DBG_PRINT("[Reconfigurable PMA]:Try to read B region from non-cacheable memory.\n");
                dcache_access_count_noncacheable_b = read_region(B_Array, TEST_ARRAY_SIZE);
                DBG_PRINT("dcache access count: %u.\n", (unsigned int)dcache_access_count_noncacheable_b);

                /* Compare the dcache access count of the region "A" (cacheable) and "B" (non-cacheable) which has different cache attribute. */
                if (CHECK_CACHE_ACCESS_COUNT(dcache_access_count_cacheable_a, dcache_access_count_noncacheable_b, TEST_ARRAY_SIZE)) {
                        DBG_PRINT("PMA-Pass of the different regions A and B with cacheable and non-cacheable attribute! \n");
                } else {
                        DBG_PRINT("PMA-Fail of the different regions A and B with cacheable and non-cacheable attribute! \n");
                        exit(FAIL);
                }
        }
#endif // TEST_REGION_B
#ifdef TEST_REGION_C
        if (run_test_C) {
                /* Access cacheable attribute region "C" */
                DBG_PRINT("[Reconfigurable PMA]:Try to read C region from cacheable memory.\n");
                dcache_access_count_cacheable_c = read_region(C_Array, TEST_ARRAY_SIZE);
                DBG_PRINT("dcache access count: %u.\n", (unsigned int)dcache_access_count_cacheable_c);

                /* Write cacheable attribute region "C" */
                write_region(C_Array, TEST_ARRAY_SIZE, 0x5a);

                /* Flush cache of region "C" */
                flush_cache((void*)C_Array, TEST_ARRAY_SIZE);

                /* Change pma configuration of the region "C" to non-cacheable attribute. */
                region_pma_config((void*)C_Array, TEST_ARRAY_SIZE, 2, PMACFG_NME(PMA_NAMO_OFF, PMA_MTYP_NONCACHEABLE, PMA_ETYP_NAPOT));

                /* Use a fence to make sure all the flushed data are out of CPU */
                asm volatile ("fence w, rw" ::: "memory");

                /* Access non-cacheable attribute region "C" */
                DBG_PRINT("[Reconfigurable PMA]:Try to read C region from non-cacheable memory.\n");
                dcache_access_count_noncacheable_c = read_region(C_Array, TEST_ARRAY_SIZE);
                DBG_PRINT("dcache access count: %u.\n", (unsigned int)dcache_access_count_noncacheable_c);

                /*
                 * Compare the dcache access count of the same region "C" with cacheable and non-cacheable attribute
                 * and check the data consistence.
                 */
                if (CHECK_CACHE_ACCESS_COUNT(dcache_access_count_cacheable_c, dcache_access_count_noncacheable_c, TEST_ARRAY_SIZE)) {
                        if (!check_region(C_Array, TEST_ARRAY_SIZE, 0x5a)) {
                                DBG_PRINT("PMA-Fail of the data consistence in the region C! \n");
                                exit(FAIL);
                        }
                        DBG_PRINT("PMA-Pass of the same region C with cacheable and non-cacheable attribute! \n");
                } else {
                        DBG_PRINT("PMA-Fail of the same region C with cacheable and non-cacheable attribute! \n");
                        exit(FAIL);
                }
        }
#endif // TEST_REGION_C

        exit(SUCCESS);
}
