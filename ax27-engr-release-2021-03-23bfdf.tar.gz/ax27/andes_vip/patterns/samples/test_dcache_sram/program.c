#include <inttypes.h>

#include "ndslib.h"
#include "core_v5.h"
#include "interrupt.h"

#if __riscv_xlen == 64
	#define ROTATE_LEN 64
#else
	#define ROTATE_LEN 32
#endif

long mdcm_cfg;

long mcache_ctl;
int dcache_way;
int dcache_set;
long mstatus;

int  index_lsb;
int  index_msb;
int  way_width;
int  way_msb;
int  xlen;

void ecall_handler(SAVED_CONTEXT * context) {
	context->mepc += 4;
	
	// Read MDCM_CFG
	mdcm_cfg        = read_csr(NDS_MDCM_CFG);

	// Ignore the testing in case of no D-CACHE
	if (((mdcm_cfg >> 6) & 0x7) == 0) {
		skip();
	}
        xlen            = ((((unsigned long long)read_csr(NDS_MISA) >> 62) & 0x3) == 0) ? 32 : 64;

        mcache_ctl      = read_csr(NDS_MCACHE_CTL);
        dcache_way      = ((mdcm_cfg >> 3) & 0x7) + 1;
        dcache_set      = ((mdcm_cfg & 0x7) + 6); // power of 2

        index_lsb       = ((mdcm_cfg >> 6) & 0x7) + 2;
        index_msb       = index_lsb + dcache_set - 1;
        way_width       = (dcache_way <= 2) ? 1 : 2;
        way_msb         = index_msb + way_width;

	// Turn on the ECC if exist
	if (((mdcm_cfg >> 10) & 0x3) != 0) {
		mcache_ctl |= 0x30;
		write_csr(NDS_MCACHE_CTL, mcache_ctl);
	}
	asm volatile ("fence.i");       // Flush all dcache data before disable it
	clear_csr(NDS_MCACHE_CTL, 2);   // Turn off dcache to avoid L/S data mismatching

        // Return to M-mode
        if (((context->mstatus >> 11) & 0x3) != 3) {
                context->mstatus |= 0x1800;
        }
}

long rotr(long num) {
	long result;
	result = (num >> 1) | (num << (ROTATE_LEN - 1));
	return result;
}

int main (int argc, char** argv) {

	// Set ECALL handler
	general_exc_handler_tab[TRAP_U_ECALL] = ecall_handler;
	general_exc_handler_tab[TRAP_S_ECALL] = ecall_handler;
	general_exc_handler_tab[TRAP_M_ECALL] = ecall_handler;

	asm volatile("ecall");

	long offset;
	long golden, test, golden_tmp;
	long data1	= 0x5a5a5a5a;

        int palen;

        // calculate PALEN
        unsigned long temp       = (xlen == 64) ? 0xFFFFFFFFFFFFFFFF : 0xFFFFFFFF;
        unsigned long mepc       = read_csr(NDS_MEPC);

        if ((read_csr(NDS_MISA) >> 18) & 0x1) { // S-Mode support
                set_csr(NDS_SATP, (unsigned long)0x1 << (xlen - 1));   // Test MMU existence
                long satp = read_csr(NDS_SATP);
                int mmu;
                if (xlen == 64) {
                        mmu = (satp >> 60);
                }
                else {
                        mmu = (satp >> 31);
                }

                if (mmu == 0) {
                        write_csr(NDS_MEPC, temp);
                        temp = read_csr(NDS_MEPC);
                        write_csr(NDS_MEPC, mepc);
                        for (palen = 0; temp != 0; palen++) {
                                temp = temp >> 1;
                        }
                }
                else {
                        temp = (xlen == 64) ? 0xFFFFFFFFFFF : 0x3FFFFF;
                        set_csr(NDS_SATP, temp);
                        temp = read_csr(NDS_SATP);
                        write_csr(NDS_SATP, satp);
                        for (palen = 0; (temp & 1) != 0; palen++) {
                                temp = temp >> 1;
                        }
                        palen = palen + 12;
                }
        }
        else {
                write_csr(NDS_MEPC, temp);
                temp = read_csr(NDS_MEPC);
                write_csr(NDS_MEPC, mepc);
                for (palen = 0; temp != 0; palen++) {
                        temp = temp >> 1;
                }
        }

        // tag ram
	asm  volatile ("tag_write:");
	test = data1;
	for (offset = (1 << index_lsb); offset < ((unsigned long)1 << way_msb); offset = offset << 1) {
		test = rotr(test);
                write_csr(0x7cb/*NDS_MCCTLBEGINADDR*/, offset);
                write_csr(0x7cd/*NDS_MCCTLDATA*/, test);
                write_csr(0x7cc/*NDS_MCCTLCOMMAND*/, 21);     //21 = L1D_IX_WTAG
	}

        int tag_lsb   = index_msb + 1;
        int tag_width = palen - 1 - tag_lsb + 1;
        long read_tag_mask = ((unsigned long long)1 << tag_width) - 1;
        long index_mask;
        if (tag_lsb == 16) {
                read_tag_mask = (read_tag_mask << 6);
                index_mask    = (1 << 6) - 1;
        }
        else if (tag_lsb == 15) {
                read_tag_mask = (read_tag_mask << 5);
                index_mask    = (1 << 5) - 1;
        }
        else if (tag_lsb == 14) {
                read_tag_mask = (read_tag_mask << 4);
                index_mask    = (1 << 4) - 1;
        }
        else if (tag_lsb == 13) {
                read_tag_mask = (read_tag_mask << 3);
                index_mask    = (1 << 3) - 1;
        }
        else if (tag_lsb == 12) {
                read_tag_mask = (read_tag_mask << 2);
                index_mask    = (1 << 2) - 1;
        }
        else if (tag_lsb == 11) {
                read_tag_mask = (read_tag_mask << 1);
                index_mask    = (1 << 1) - 1;
        }
        else {
                index_mask    = 0;
        }
        read_tag_mask = read_tag_mask + ((unsigned long)7 << (xlen - 3));
	asm  volatile ("tag_read:");
	golden =  data1;
	for (offset = (1 << index_lsb); offset < ((unsigned long)1 << way_msb); offset = offset << 1) {
		golden = rotr(golden);
                write_csr(0x7cb/*NDS_MCCTLBEGINADDR*/, offset);
                write_csr(0x7cc/*NDS_MCCTLCOMMAND*/, 19);     //19 = L1D_IX_RTAG
                test = read_csr(0x7cd/*NDS_MCCTLDATA*/);
                golden_tmp = golden & read_tag_mask;
                golden_tmp = golden_tmp + (((offset >> 12) << 2) & index_mask);
		if (golden_tmp != test) {
			exit(1);
		}
	}

        // data ram
        int offset_lsb = (xlen == 64) ? 3 : 2;

        asm  volatile ("data_write:");
        test = data1;
        for (offset = (1 << offset_lsb); offset < ((unsigned long)1 << way_msb); offset = offset << 1) {
                test = rotr(test);
                write_csr(0x7cb/*NDS_MCCTLBEGINADDR*/, offset);
                write_csr(0x7cd/*NDS_MCCTLDATA*/, test);
                write_csr(0x7cc/*NDS_MCCTLCOMMAND*/, 22);     //22 = L1D_IX_WDATA
        }

        asm  volatile ("data_read:");
        golden =  data1;
        for (offset = (1 << offset_lsb); offset < ((unsigned long)1 << way_msb); offset = offset << 1) {
                golden = rotr(golden);
                write_csr(0x7cb/*NDS_MCCTLBEGINADDR*/, offset);
                write_csr(0x7cc/*NDS_MCCTLCOMMAND*/, 20);     //20 = L1D_IX_RDATA
                test = read_csr(0x7cd/*NDS_MCCTLDATA*/);
                if (golden != test) {
                        exit(1);
                }
        }
}
