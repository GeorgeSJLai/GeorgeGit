import csv
#inF = open("input.csv")
with open("input.csv") as inF:
    csvReader = csv.reader(inF)
    listReport = list(csvReader)

ouF = open("output.csv",'w',newline='')
csvWriter = csv.writer(ouF, delimiter=' ')
for row in listReport:
    csvWriter.writerow(row)
csvWriter.writerow(['----------'])
for row in listReport:
    csvWriter.writerow(row)
csvWriter.writerow(['花茶','15'])
csvWriter.writerow(['蜜茶','10'])
ouF.close()

