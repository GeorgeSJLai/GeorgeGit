import json
with open("drugstore.json",encoding='utf-8') as jsonIn:
    data = json.load(jsonIn)
i=0
for item in data:
    if item['地址縣市別']=='新北市' and item['機構狀態']=='開業':
        i += 1
        if i >= 11 and i <= 20:
            print("{:}\t{:}{:}{:}".format(item['機構名稱'],item['地址縣市別'],item['地址鄉鎮市區'],item['地址街道巷弄號']))

    
    
    