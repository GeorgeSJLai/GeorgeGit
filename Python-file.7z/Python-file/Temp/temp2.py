

import math
#print(chr(12))  #FormFeed
#print(chr(7))
a = "Python/Java程式設計"
b = "PythonJava程式設計"
c = "一二三123四五"
print("\f")
x=input("...Press The Enter to Exec...")
print('{:d}'.format(ord(a[2])),end="/1/")
print(len(a+a))
# print(max(a))
print(min(a))
print("a" in "qqawwe",end=" || ")
print("a" not in "qqawwe")
print(a.upper(),a.swapcase(),sep='\t')
print(a.lower(),a.capitalize(),sep='\t')
print(a[4:9],a.title(),a.replace('Java','jAVA'))
print(b.isidentifier(),c.isnumeric())
print((a+b+c).count('計'),(a+b+c).startswith('Pyth'))
print((a+b+c).endswith(c),(a+b).find('程'),(a+b+c+c).rfind('程'))
print((a+b+c).strip('Pyth四五'))
print('abcxyzd ef'.strip('abcdef'))
Z = 'tw.yahoo.com'
print(Z.lstrip('.tomw'),Z.rstrip('.tomw'),Z.strip('.tomw'))
print(12345678901234567890)
print(format(-12345,'+11,'))
print(format('4567890','^11'))
print(round(557.5),round(556.5),round(-557.5),round(-556.5),sep='/')
print(format(math.pi,'_^24'),format(math.e,'_^24'),sep='|')
