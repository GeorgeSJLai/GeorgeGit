n={}
nn = None
if __name__ == "__main__":
    print(12+6.1234567890123456789)
    print(bool(0.000000001),bool([]),bool(n),bool(nn),(77>=9),sep='\\',end="/")
    print(ord('`'))
    print('''1234567890
abcdefghAB\nCDEFGHhh
123456789012345''')
    print("\tit's \r12\"4'678")
    a=11123//111;print(type(a))
    a="aaa";print(type(a))
    a=False;print("Str:%s" % type(a))
    a+=1;a/=2;print(type(a))
    中文 = 11.1
    bz=bin(0XAB)
    b=hex(0x1_23)
    bb=oct(0xA_BC)
    bbb=int(b,0)
    c=eval(b)
    #print("\n")
    #d = input("\tinp>")
    d = '1456.889'
    print("\t\tFloat:%6.3f, b:%9s.\rInt:%-8d," % (float(d), b[1:5], float(d)))
    #c/=7
    print('123456789012345678901234567890')
    print('{:^+14.3f}'.format(-4466)) 
    print('{0:^11.2%} \ {0:^.2f}'.format(1.1569))
