# -*- coding: utf-8 -*-
import math,random
def test000(a=1,b=111222333):
    if a==0:
        print("123456789012345678901234567890",x)
    elif a==1:
        print(format(b,"_^33,"),x)
    elif a==2:
        print(format(b,"|>+33,"))
    elif a==3:
        print(format(math.pi,'-^44'))
    elif a==4:
        print(round(5566.5),round(5567.5),round(-5566.5),round(-5567.5),sep='|')
    return math.e
x=999
print("\f")
xx=input("...Press Enter to Exec...")
ccc=9876543210
e=test000(a=0)
e=test000(b=ccc+777)
e=test000(b=ccc,a=2)
e=test000(3)
e=test000(4)
print(format(e,'_^33,'))
print("ddd" in "fghjkkkddddmmmmm")
lista = str(random.randint(1,5))
lista += str(random.randint(1,5))
lista += str(random.randint(1,5))
lista += str(random.randint(1,5))
lista += str(random.randint(1,5))
