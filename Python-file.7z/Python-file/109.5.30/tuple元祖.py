# tuple 數組.元組.序對，指的是由一連串資料組成，有順序，不可改變的內容序列
# tuple 以小括號() 表示，裡面的元素以逗號隔開，資料型態可以不同
tup1 = tuple()
print(tup1)

tup2 = tuple((1, 3, 5))
print(tup2)

tup3 = ()
print(tup3)

tup4= (2, 4, 6)
print(tup4)