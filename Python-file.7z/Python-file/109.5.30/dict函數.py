#字典 dict 相關函數

dic ={'X' : 123, 'Y' : 456, 'Z' :789}

print("字典 dic =",dic)

print(dic.keys()) #只印出字典的索引

print(dic.values())#只印出字典的索引值

print(dic.items()) #印出字典的索引和索引值  
