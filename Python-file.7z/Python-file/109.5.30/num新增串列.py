num1 =[1, 3, 5, 7, 9]
num2 =[2, 5, 8, 11, 14]

num1.append(11)# 將 整數11新增 num1 串列的最後面
print("num1 =" ,num1)

num1.extend(num2)# 將 num2附加 num1 串列的最後面
print("num1 =", num1)

print(num1.count(11))# 計算整數 11在串列 num1 出現的次數

print(num1.index(9))# num1 的某個索引的索引值

print(num1.insert(3,999))# 將 整數 999值，插入到串列為3的位置

print("num1 = ",num1)

p1 = num1.pop()
print("pop =", num1)
print("num1 =", num1)

r1 =num1.remove(5)
print("num1 =", num1) 


