#串列解析(List comprehension)

#串列生成提供一個簡潔的方式來建立串列
#串列有一個for 敘述，後面跟著 0個或一個 或多個for 或 if敘述
#串列的元素，就是運算式產生的結果


listc1 = [i for i in range(10)]#產生從0 到 9 的串列
print("listc1 = ", listc1)

listc2 = [j+3 for j in range(10)]
print("listc2 = ", listc2)

listc3 = [k*4 for k in range(10)]
print("listc3 = ", listc3)
