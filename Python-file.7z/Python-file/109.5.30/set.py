# -*- coding: utf-8 -*-
"""
Created on Sat May 30 10:46:31 2020

@author: ASUS
"""


A = set()#定義一個空的集合
A.add(3)#新加入整數3 到集合內
A.add("ABC")#新加入字串ABC 到集合內
A.add(True)#新加入True 到A集合內
print("集合A =",A)

print(3 in A)#判斷整數3 是否在A集合內

x= {'a','b',1,2}
y= {1,2,'a','b'}
print(x==y)#判斷 集合X 是否等於集合Y

print("集合X =",x)
print("集合y =",y)
