#建立字典後，可以透過key索引，來取得對應的value索引值

A ={'one':1, 'two':2, 'three':3}

X = A['one']

print("X =", X)

#用dictName[key] = value 的語法來新增或變更索引值

print("變更前 A['two'] =",A["two"])

A['two'] = 200

print("變更後 A['two'] =",A["two"])

