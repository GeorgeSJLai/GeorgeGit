#in      運算子:檢查某個元素是否 存在於串列內
#not in  運算子:檢查某個元素是否不存在於串列內
print(3 in [1, 2, 3, 4, 5])

print('Y' in ['XYZ', 'ABC'])

print('Y' in ['XYZ', 'ABC', 'Y'])

print('XYZ' in ['XYZ', 'ABC'])


