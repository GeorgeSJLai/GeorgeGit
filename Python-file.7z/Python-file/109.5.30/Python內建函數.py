#Python 內建函數:
#sort() 會直接修改原始的list，並且排序完成
#sorted() 不會修改原始的list，會回傳一個排序好的新的list

#如果要保留原始的list串列，就要用 sorted產生一個排序好的新list
#如果不要保留原始的list串列，就可以使用 sort() 排序


X = [1, 3, 2, 4, 5]

print(sorted(X))#只回傳排序好的值，不會動到原始串列內容值

print("X =" , X)

X.sort()#排序時就會直接更新串列內的值，蓋掉 List 原始值
print("X = " , X)

