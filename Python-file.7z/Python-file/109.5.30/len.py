# -*- coding: utf-8 -*-
"""
Created on Sat May 30 10:30:33 2020

@author: ASUS
"""


A={1,3,5,7,9,5,7,3}#指定集合1,3,5,7,9

print("len(A)=",len(A))#計算及

print("max(A)=",max(A))

print("min(A)=",min(A))

print("sum(A)=",sum(A))