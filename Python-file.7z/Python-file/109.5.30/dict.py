
X = {'A': 567, 'B':789} #字典X (DICT)
Y = {'B': 789, 'A':567} #字典Y (DICT)
Y = {'B': 789, 'A':567}

print(X == Y)

print("X = ", X)
print("Y = ", Y)

