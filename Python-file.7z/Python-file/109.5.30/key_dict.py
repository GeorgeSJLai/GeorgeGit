#下面四個敘述會建立包含key:value的字典

A = {"one" :1,"two" : 2,"three": 3}         #寫法1
B = dict({"one":1,"two":2,"three":3})       #寫法2
C = dict(one=1, two=2, three=3)             #寫法3
D = dict([("one",1),("two",2),("three",3)]) #寫法4

print(A == B == C == D)

print("字典 A =", A)
print("字典 B =", B)
print("字典 C =", C)
print("字典 D =", D)



