# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 15:26:34 2020

@author: ASUS
"""
#比較(關係)運算子
print(123 =='123')
print('ABC' == 'abc')
print(True == 1)
print(False == 0)
print(3>5)
print(3>5==True)
print('-------')
#邏輯運算子
print(3>2 and 2>3)
print(3>2 or 3>2)
print(not 3>2)