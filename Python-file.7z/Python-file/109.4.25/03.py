# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 12:06:06 2020

@author: ASUS
"""

print(5<3)
print(5>3)
print(bool(0))
print(bool(0.0))
print(bool(0.1))
print(bool())
print(bool(None))
print(bool(True))
print(bool(False))
print(bool(())) 
print(bool([])) 
print(bool({}))