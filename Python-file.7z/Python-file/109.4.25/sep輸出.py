# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:28:45 2020

@author: ASUS
"""
#輸出
name1='Kevin'
name2='Tank'
print('Hello',name1,name2,sep='***')
print('World',name1,name2,sep='$$$')

print(123, 23.56, True, "abc" ,sep=':::')
print("testa")

print(123, 23.56, True, "abc" ,sep=':::',end='---')
print("testb")
print("testc")