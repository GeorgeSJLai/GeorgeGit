# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 11:04:53 2020

@author: ASUS
"""

#-Python單行註解
'''---Python多行註解---'''

print(type(10))
print(type(10.0))
print(type('XYZ'))      