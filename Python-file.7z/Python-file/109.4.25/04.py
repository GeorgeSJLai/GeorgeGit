# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 12:21:50 2020

@author: ASUS
"""

print('Python程式設計')
print("Python程式設計")
print('''Python程式設計''')
print("""Python程式設計""")
