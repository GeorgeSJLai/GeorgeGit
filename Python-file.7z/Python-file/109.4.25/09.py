# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 15:56:57 2020

@author: ASUS
"""
x,y,z= 10,20,30 
x+=y #x=x+y
print(x)

x,y,z= 10,20,30 
x-=y #x=x-y
print(x)

x,y,z= 10,20,30 
x*=y #x=x*y
print(x)

x,y,z= 10,20,30 
x/=y #x=x/y
print(x)

x,y,z= 10,20,30 
x%=y #x=x%y
print(x)