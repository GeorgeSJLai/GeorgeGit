# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 15:15:22 2020

@author: ASUS
"""

print(1+2)
print(1.2+3.9)

print(20-6)
print(30-True)
      
print(12*21)
print('ABC'*2)

print(8/3)
print(12/True)

print(88 // 6)
print(100 // 9)

print(20 % 10)
print(12.5 % 10)      

print(5 ** 3)
print(3 ** 6)