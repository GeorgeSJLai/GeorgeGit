# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:17:55 2020

@author: ASUS
"""

name=input("請輸入姓名:")
print(name)



