# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 14:55:09 2020

@author: ASUS
"""

a=1
b=3
c=5.5
d=7.5
print(int(a+c),int(a+d))
print(float(a+b))

print(int('10'))
print(int(True))
print(int(False))
print(int(3.13145))
print(str(3.13147))      