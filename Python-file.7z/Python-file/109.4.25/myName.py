# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 16:52:53 2020

@author: ASUS
"""
#輸出字串
print('I','am','Ken')
print('I','am','Ken',sep='@')
print('I','am','Ken',end='&&&')
print()
myName="超人"
print("我的","名字是",myName)
