# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 11:41:41 2020

@author: ASUS
"""

print(10)
print(1000+2000)
print(1,000000)
print(123.321)
print(123.321+321.123)