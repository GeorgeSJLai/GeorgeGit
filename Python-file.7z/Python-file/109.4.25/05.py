# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 12:30:39 2020

@author: ASUS
"""

print('c:\tond')
print('c:\\tond')
print('it\'is')
print('\"it\" is')
print('is\tit?')
print('is it OK?\nYES!')

myName='Ken'
print(myName)

x=3
x=x+1
print(x)

x=y=z=123
print(x)
print(y)
print(z)