import json
with open(r"C:\Python-file\JSON\NewBike.json",encoding='utf-8-sig') as jsonIn:
	data = json.load(jsonIn)
for item in data:
    print(item['sno'],item['sna'],item['tot'])
