import json
with open(r"C:\Python-file\JSON\Object.json") as jsonIn:
	data = json.load(jsonIn)
print(data)
print(type(data))

with open(r"C:\Python-file\JSON\ObjOut.json",'w') as jsonOut:
    json.dump(data, jsonOut, ensure_ascii=False)
print("="*30)
with open(r"C:\Python-file\JSON\ObjectArray.json") as jsonAr:
	ArrayD = json.load(jsonAr)
print(ArrayD)
print(type(ArrayD))
print(type(ArrayD[5]))

with open(r"C:\Python-file\JSON\ArrayOut.json",'w') as ArOut:
    json.dump(ArrayD,ArOut)