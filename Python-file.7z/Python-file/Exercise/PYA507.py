# TODO
def compute(a):
    if a < 2:
        return 'Not Prime'
    for i in range(2,a):
        if a%i==0:
            return 'Not Prime'
    return 'Prime'
numA = eval(input())
print(compute(numA))
