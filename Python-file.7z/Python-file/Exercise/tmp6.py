﻿print("\f")
a = aa = eval(input("Any Number:"))
l_a = list(range(7,a+1,11))
l_b = [j for j in range(7,a+1,11)]
kk = True if l_a+l_b==l_b*2 else False
print(l_a[:],l_b[:],kk,sep='\n')
c = [1,2,3]
l_a.append(c[0])
l_a.append(c[1])
l_a.append(c[2])
l_b.extend(c)
print(l_a,l_b,sep='\n')
ta = tuple(range(3,a+1,11))
tb = tuple(j for j in range(3,a+1,11))
print("ta/tb=",ta,tb)
sa=set()
sa = set(l_a)
sb = set(l_b)
for i in sb:
    print(i,end='/')
print({1,2,3}=={3,1,2})
da = {1: '11', 4: '44', 2: '22'}
db = {1: '11', 2: '22', 4: '44'}
print(da.keys(),da.values(),da.items())
print("====Done====")
