# TODO
listA = []
for i in range(5):
    card = input()
    if card.upper()=="J":
        listA.append(11)
    elif card.upper()=="Q":
        listA.append(12)
    elif card.upper()=="K":
        listA.append(13)
    elif card.upper()=="A":
        listA.append(1)
    else:
        listA.append(int(card))
print(sum(listA))
        