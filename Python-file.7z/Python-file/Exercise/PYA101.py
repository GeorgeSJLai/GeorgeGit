#TODO
a=input('')
b=input('')
c=input('')
d=input('')
#向右靠齊
print('|{:>5s} {:>5s}|'.format(a,b))
print('|{:>5s} {:>5s}|'.format(c,d))
#TODO
#向左靠齊
print('|{:<5s} {:<5s}|'.format(a,b))
print('|{:<5s} {:<5s}|'.format(c,d))
#TODO8585
