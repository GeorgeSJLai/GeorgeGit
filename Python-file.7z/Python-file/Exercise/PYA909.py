f_name = "data.dat"
file = open(f_name,'w', encoding='UTF-8')
# TODO
listA = list()
for i in range(5):
    txtin = input()
    listA = txtin.split()
    file.write('{0:s} {1:s}\n'.format(listA[0],listA[1]))
file.close()
print('The content of "data.dat":')

"""
The content of "data.dat":
"""