# #TODO
a=eval(input())
b=eval(input())
c=eval(input())
d=eval(input())
#向右靠齊
print('|{:>7.2f} {:>7.2f}|'.format(a,b))
print('|{:>7.2f} {:>7.2f}|'.format(c,d))
#TODO
#向左靠齊
print('|{:<7.2f} {:<7.2f}|'.format(a,b))
print('|{:<7.2f} {:<7.2f}|'.format(c,d))
#TODO
