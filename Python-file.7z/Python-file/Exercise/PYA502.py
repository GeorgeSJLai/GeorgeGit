# TODO
def compute(a,b):
    return a*b
numA = eval(input())
numB = eval(input())
print(compute(numA,numB))
