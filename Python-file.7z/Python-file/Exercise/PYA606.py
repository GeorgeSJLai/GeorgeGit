# TODO
row = eval(input())
col = eval(input())
for i in range(row):
    for j in range(col):
        print('{:4d}'.format(j-i),end='')
    else:
        if i==(row-1):
            pass
        else:
            print(' ')

        