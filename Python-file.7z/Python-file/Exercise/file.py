﻿A='''1234567890
abcdefghAB\nCDEFGHhh
123456789012345'''
    
print("File test python",file=open(r'C:\Python-file\Exercise\data2.txt','w'))

f = open(r'C:\Python-file\Exercise\data2.txt','a')
f.write(A)
#f.close()


with open(r'C:\Python-file\Exercise\data2.txt') as f:
    context = f.read()
    B = context.splitlines()
    print(context.strip("test"),"\n====================")
    print(B)
    

