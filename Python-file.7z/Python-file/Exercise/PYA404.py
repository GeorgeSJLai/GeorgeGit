# TODO
a = input()
for i in range(-1,-1*len(a),-1):
    print(a[i],end='')
print(a[0],end='')
