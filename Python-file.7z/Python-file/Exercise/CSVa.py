import csv
#f = open(r"C:\Python-file\Samples\COA_OpenData.csv",encoding='utf-8')
#f = open(r"C:\Python-file\Samples\BOM.csv",encoding='utf-8-sig')
f = open(r"C:\Python-file\Samples\UTF-8.csv",encoding='utf-8-sig')
f = open(r"C:\Python-file\Samples\UTF-8.csv",encoding='utf-8')
csvReader = csv.reader(f)
'''csvList = list(csvReader)
print(csvList[0][:3])
print(csvList[1][:3])
print(csvList[2][:3])'''
for row in csvReader:
    print("Row {:d} =".format(csvReader.line_num), row)

