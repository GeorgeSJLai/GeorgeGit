# TODO
a = eval(input())
b = eval(input())
op = input()

if op=="+":
    print(a+b)
elif op=="-":
    print(a-b)
elif op=="*":
    print(a*b)
elif op=='/':
    print(a/b)
elif op=="//":
    print(a//b)
elif op=="%":
    print(a%b)
