# TODO
A = []
for i in range(12):
    inum = eval(input())
    A.append(inum)
sum=0
for i in range(12):
    print('{:3d}'.format(A[i]),end='')
    if i%2==0:
        sum += A[i]
    if i%3==2:
        print("")
print(sum)
