﻿print("\f")
a = aa = eval(input("Any Number:"))
while aa<800:
    print(aa,end=" ")
    if aa>666 and aa<678:
        aa+=1
        continue
    aa+=7
    if aa>699:
        break
else:
    print("\t"+str(aa))

if (a%2 and a%7) or a==0:
    print(str(a),"不是2也不是7的倍數",sep="")
elif a%2==0 and a%7==0:
    print(str(a),"是2及7的倍數",sep="")
elif a%2==0 and a%7:
    print(str(a),"是2的倍數",sep="")
else:
    print(str(a),"是7的倍數",sep="")

'''elif 
    print(str(a),"是7的倍數",sep="")
else:
    print(str(a),"是2及7的倍數",sep="")'''

a = "asdfghjqk"
for i in a:
    if i.upper()=="S":
        continue
    print(i,end="")
    if i.upper()=="Q":
        break
else:
    print(i,end="")
print("\n====Done====")
