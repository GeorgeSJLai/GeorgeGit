# TODO
with open('read.txt') as f:
    A = f.read()
lista = A.split()
tot=0
for i in lista:
    tot+= int(i)
print(tot)
        