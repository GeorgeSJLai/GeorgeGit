﻿print("\f")
a = eval(input("Any Number:"))
if a%2==0 and a!=0:
    print(str(a),"是2",end="",sep="")
    if a%7==0:
        print("及7",end="")
    print("的倍數")
elif a%7==0 and a!=0:
    print(str(a),"是7的倍數",sep="")
else:
    print(str(a),"不是2也不是7的倍數")
print("====Done====")