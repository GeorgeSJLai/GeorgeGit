# TODO
num = eval(input())
sum=0
for i in range(1,num+1):
    if i%5==0:
        sum += i
print(sum)
    
    