# TODO
minNum = None
while True:
    a = eval(input())
    if a == 9999:
        break
    if minNum==None:
        minNum = a
    elif minNum > a:
        minNum = a
print(minNum)
        
    