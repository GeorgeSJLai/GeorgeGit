# TODO
ichar = input()
print(ichar.upper())
print(ichar.title())
