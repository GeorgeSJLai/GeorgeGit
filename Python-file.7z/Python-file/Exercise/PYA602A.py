# TODO
A=1
J=11
Q=12
K=13
sum=0
for i in range(5):  sum += eval(input())
print(sum)
        