# TODO
name=[]
hight=[]
weight=[]
with open('read.txt') as f:
    for line in f:
        tmp = line.strip('\n').split()
        print(line)
        name.append(tmp[0])
        hight.append(eval(tmp[1]))
        weight.append(eval(tmp[2]))

print('Average height: {:.2f}'.format(sum(hight)/len(hight)))
print('Average weight: {:.2f}'.format(sum(weight)/len(weight)))
indexH = hight.index(max(hight))
print('The tallest is {:s} with {:.2f}cm'.format(name[indexH],hight[indexH]))
indexW = weight.index(max(weight))
print('The heaviest is {:s} with {:.2f}kg'.format(name[indexW],weight[indexW]))
