# TODO
listA = []
for i in range(10):
    listA.append(eval(input()))

for i in listA:
    if listA.count(i) > 1:
        break
print(i)
print(listA.count(i))
