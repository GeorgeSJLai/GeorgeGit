﻿print("\f")
a = eval(input("輸入數字:"))
sum=0
for i in range(0,a+1,7):
    sum+=i
print('從1到{}的總和是:{}'.format(a,sum))
print("====Done====")