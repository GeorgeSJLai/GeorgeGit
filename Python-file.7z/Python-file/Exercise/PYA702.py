# TODO
tup1 = tuple()
print("Create tuple1:")
while True:
    inum = eval(input())
    if inum==-9999:
        break
    tup1 += (inum,)
tup2 = tuple()
print("Create tuple2:")
while True:
    inum = eval(input())
    if inum==-9999:
        break
    tup2 += (inum,)
tupAll = tup1 + tup2
print('Combined tuple before sorting:',tupAll)
print('Combined list after sorting:',sorted(list(tupAll)))
# TODO


"""
Combined tuple before sorting: _
Combined list after sorting: _
"""
