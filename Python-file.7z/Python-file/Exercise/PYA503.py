# TODO
def compute(a,b):
    sum=0
    for i in range(a,b+1):
        sum+=i
    return sum 
numA = eval(input())
numB = eval(input())
print(compute(numA,numB))
