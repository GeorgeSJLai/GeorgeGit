
# TODO
import math
PI = math.pi
radius = eval(input())

print('Radius = {:.2f}'.format(radius))
print('Perimeter = {:.2f}'.format(radius*PI*2))
print('Area = {:.2f}'.format(pow(radius,2)*PI))
# TODO

"""
Radius = _
Perimeter = _
Area = _
"""
