import csv
inF = open(r"C:\Python-file\Samples\COA_OpenData.csv",encoding='utf-8')
csvReader = csv.reader(inF)
listReport = list(csvReader)

ouF = open(r"C:\Python-file\Samples\WriteData.csv",'w',newline='',encoding='utf-8')
csvWriter = csv.writer(ouF)
for row in listReport:
    csvWriter.writerow(row)
ouF.close()


