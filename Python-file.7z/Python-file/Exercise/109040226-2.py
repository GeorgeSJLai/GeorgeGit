def toupper(a):
    print(a.upper())
    
def totitle(a):
    print(a.title())

print("\f")
a = input("Any String:")
toupper(a)
totitle(a)
print("====Done====")