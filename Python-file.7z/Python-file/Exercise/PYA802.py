# TODO

char = input()
total = 0
for i in char:
    print("ASCII code for '{}' is {}".format(i,ord(i)))
    total += ord(i)
print(total)


"""
ASCII code for '_' is _
"""