import json
#with open(r"C:\Python-file\Exercise_6\meals.json") as jsonIn:
ddd = {"breakfast":50,"lunch":80,"dinner":100}
with open("jsonoutput.json",'w') as jsonIn:
    json.dump(ddd,jsonIn)
with open("jsonoutput.json") as jsonIn:
    data = json.load(jsonIn)
print('早餐費用:{:d}元'.format(data['breakfast']))
print('午餐費用:',data['lunch'],"元",sep='')
#print('晚餐費用:{:d}'.format(data['dinner']))
print(format('晚餐費用:'+str(data['dinner'])+'元','s'))
