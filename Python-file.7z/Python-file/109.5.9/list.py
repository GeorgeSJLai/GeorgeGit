X= list() # 建立空字串 :寫法1
print("X= ",X)

Y= list([1,2,3])
print("Y= ",Y)

X2=[] # 建立空字串 :寫法2
print("X2= ",X2)

Y2=[1,2,3]
print("Y2= ",Y2)

print("-----------")

# list串列:裡面的元素是有順序，順序不一樣就是不一樣
# list 是最常用的資料結構，以中括號[]來表示
# 串列內的元素型態可以不同，使用索引位置可存取元素

list1 = [1, 2.5, 'xyz', False] #串列可有不同資料型態

print(type(list1)) #用type函數可列出資料型態

print(list1[0]) #顯示list1的第一個元素

print(list1[2]) #索引值由零開始

