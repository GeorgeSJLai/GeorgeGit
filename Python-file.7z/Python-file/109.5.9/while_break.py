#while 迴圈 搭配break 敘述
answer = input("請輸入[好]的英文:")

while answer.upper() !="GOOD":#upper 函數可將字串
    if answer.upper() =="QUIT":
        print("跳開")
        break  #跳開此迴圈
    answer = input("答錯了! 請重新輸入[好]的英文:")
else:
    print("答對了!")    

