# for 迴圈 搭配 range
'''
for i in range(5):
    print(i)
'''
#for 迴圈計算個數    

name = 'Kevin Chen'

#len 計算個數
print("len(name)=" ,len(name))

for i in range(len(name)):
    print(i ,name[i])    
