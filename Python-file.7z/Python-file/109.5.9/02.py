# -*- coding: utf-8 -*-
"""
Created on Sat May  9 11:02:59 2020

@author: ASUS
"""
# 雙向 if (if+ else)

score = eval(input("請輸入分數 (0- 100):"))
if score >60:
    print("及格")
else:
    print("不及格")    

#