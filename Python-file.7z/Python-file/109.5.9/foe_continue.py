# for 迴圈 搭配continue 應用

text = input("請輸入一個字串:")
for letter in text:#letter 是變數
    if letter.isupper():#isupper判斷字母為大寫
        continue #回到迴圈，大寫字母跳過不印出
    print(letter,end = " ") # end指結尾放空格