#while迴圈 搭配continue
i = 0

while i<10:
    i=i+1
    if i%3 !=0: # % 是指取餘數
        continue
        print("不會執行這一行，回到迴圈")
    print(i)    

