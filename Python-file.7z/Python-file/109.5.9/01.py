# -*- coding: utf-8 -*-
"""
Created on Sat May  9 10:09:56 2020

@author: ASUS
"""
#單向 if
a=100
b=200

if a<b:
    print(a)
    


x=15
y=10

if x>y:
    z=x-y
    print("x 比 y 大",z)
        
