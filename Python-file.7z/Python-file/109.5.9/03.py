"""
#多向 if (if+ elif+ else(多選一))
score = eval(input("請輸入分數 (0- 100):"))

if score >= 90:
    print("優等")

elif score < 90 and score>=80:#輸入的分數區間 90 >score>=80
    print("甲等")

elif score < 80 and score>=70:#輸入的分數區間 80 >score>=70
    print("乙等")

elif score < 70 and score>=60:#輸入的分數區間 70 >score>=60
    print("丙等")
else:
    print("不及格") #輸入的分數不在上面 ，只要 < 60，就會印出不及格  
"""
#巢狀 if
score = eval(input("請輸入分數 (0- 100):"))
if score >= 90:
    print("優等")
else:
    if score>=80:
        print("甲等")
    else:
        if score >=70:
            print("乙等")
        else:
            if score>=60:
                print("丙等")
            else:
                print("不及格")
        
    