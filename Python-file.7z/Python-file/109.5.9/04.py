#迴圈 while
i = 0
while i<5:
    print(i)
    i = i+1

#while 迴圈用於不定數    
answer = input("請輸入[快樂]的英文:")
#upper() 用途將英文字母將小寫轉為大寫
while answer.upper() !="HAPPY":
    answer = input("答錯了，請重新輸入:")
else:
    print("答對了")    
